﻿{
     "language-charting-no-items": "No charts to display",
     "language-charting-selector-text": "Select Charts",
     "language-charting-smart-panel-maximize-restore": "Maximize/Restore Panel",
     "language-charting-smart-panel-resize": "Drag to resize the panel",
     "language-common-close": "Close",
     "language-feature-charts": "Charts",
     "language-feature-no-chart": "No chart",
     "language-framework-ui-view-container-view-back": "Go Back {0}",
     "language-framework-ui-view-container-view-close": "Close {0}"
}