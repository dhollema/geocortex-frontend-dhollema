﻿{
     "language-framework-ui-view-container-view-back": "Go Back {0}",
     "language-framework-ui-view-container-view-close": "Close {0}"
}