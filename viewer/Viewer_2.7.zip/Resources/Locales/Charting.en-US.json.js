﻿{
     "language-charting-chart": "Chart",
     "language-charting-chart-name": "Name of chart",
     "language-charting-chart-series": "Series visualized",
     "language-charting-chart-type": "Type of chart"
}