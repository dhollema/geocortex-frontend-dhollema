//>>built
define("dijit/nls/sr/loading",{loadingState:"U\u010ditavanje...",errorState:"Na\u017ealost, do\u0161lo je do gre\u0161ke"});