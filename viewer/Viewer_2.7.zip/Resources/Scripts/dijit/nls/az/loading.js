//>>built
define("dijit/nls/az/loading",{loadingState:"Y\u00fckl\u0259nir...",errorState:"Problem yarand\u0131"});