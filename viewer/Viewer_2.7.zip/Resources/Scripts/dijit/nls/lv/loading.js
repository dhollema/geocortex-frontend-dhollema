//>>built
define("dijit/nls/lv/loading",{loadingState:"Iel\u0101d\u0113...",errorState:"Diem\u017e\u0113l rad\u0101s k\u013c\u016bda"});