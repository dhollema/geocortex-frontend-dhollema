//>>built
define("dijit/nls/lv/common",{buttonOk:"Labi",buttonCancel:"Atcelt",buttonSave:"Saglab\u0101t",itemClose:"Aizv\u0113rt"});