//>>built
define("dijit/nls/et/common",{buttonOk:"OK",buttonCancel:"T\u00fchista",buttonSave:"Salvesta",itemClose:"Sulge"});