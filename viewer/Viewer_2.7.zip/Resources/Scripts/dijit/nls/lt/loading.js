//>>built
define("dijit/nls/lt/loading",{loadingState:"\u012ekeliama...",errorState:"Atsipra\u0161ome, \u012fvyko klaida"});