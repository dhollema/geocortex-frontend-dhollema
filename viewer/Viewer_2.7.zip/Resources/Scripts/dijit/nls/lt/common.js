//>>built
define("dijit/nls/lt/common",{buttonOk:"Gerai",buttonCancel:"At\u0161aukti",buttonSave:"\u012era\u0161yti",itemClose:"U\u017everti"});