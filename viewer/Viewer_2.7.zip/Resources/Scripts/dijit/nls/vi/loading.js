//>>built
define("dijit/nls/vi/loading",{loadingState:"\u0110ang t\u1ea3i...",errorState:"R\u1ea5t ti\u1ebfc, \u0111\u00e3 x\u1ea3y ra l\u1ed7i"});