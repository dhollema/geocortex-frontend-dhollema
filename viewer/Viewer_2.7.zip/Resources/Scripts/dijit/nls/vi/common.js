//>>built
define("dijit/nls/vi/common",{buttonOk:"OK",buttonCancel:"H\u1ee7y",buttonSave:"L\u01b0u",itemClose:"\u0110\u00f3ng"});