//>>built
define("dijit/form/nls/et/ComboBox",{previousMessage:"Varasemad valikud",nextMessage:"Rohkem valikuid"});