//>>built
define("dijit/form/nls/nl/ComboBox",{previousMessage:"Eerdere opties",nextMessage:"Meer opties"});