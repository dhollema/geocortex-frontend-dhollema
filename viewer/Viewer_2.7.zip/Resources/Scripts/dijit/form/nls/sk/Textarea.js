//>>built
define("dijit/form/nls/sk/Textarea",{iframeEditTitle:"upravi\u0165 oblas\u0165",iframeFocusTitle:"upravi\u0165 r\u00e1mec oblasti"});