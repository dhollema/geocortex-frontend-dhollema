/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/et/number",{group:",",percentSign:"%",exponential:"E",scientificFormat:"#E0",percentFormat:"#,##0%",list:";",infinity:"\u00e2\u02c6\u017e",minusSign:"-",decimal:".",superscriptingExponent:"\u00c3\u2013",nan:"NaN",perMille:"\u00e2\u20ac\u00b0",decimalFormat:"#,##0.###",currencyFormat:"\u00c2\u00a4#,##0.00;(\u00c2\u00a4#,##0.00)",plusSign:"+","decimalFormat-long":"000 triljonit","decimalFormat-short":"000T"});