/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/et/currency",{HKD_displayName:"Hongkongi dollar",CHF_displayName:"\u0160veitsi frank",JPY_symbol:"\u00c2\u00a5",CAD_displayName:"Kanada dollar",CNY_displayName:"Hiina j\u00fcaan",USD_symbol:"$",AUD_displayName:"Austraalia dollar",JPY_displayName:"Jaapani jeen",USD_displayName:"USA dollar",GBP_displayName:"Suurbritannia naelsterling",EUR_displayName:"Euro"});