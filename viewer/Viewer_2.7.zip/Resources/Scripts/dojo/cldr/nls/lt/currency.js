/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/lt/currency",{HKD_displayName:"Honkongo doleris",CHF_displayName:"\u0160veicarijos frankas",JPY_symbol:"\u00c2\u00a5",CAD_displayName:"Kanados doleris",CNY_displayName:"Kinijos juanis",USD_symbol:"$",AUD_displayName:"Australijos doleris",JPY_displayName:"Japonijos jena",USD_displayName:"JAV doleris",GBP_displayName:"Britanijos svaras sterling\u0173",EUR_displayName:"Euras"});